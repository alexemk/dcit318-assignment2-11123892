# DCIT 318 Assignment 2

This repository contains three C# console applications demonstrating OOP concepts:

1. Inheritance and Method Overriding
2. Abstract Classes and Methods
3. Interfaces

Each concept is implemented in a separate folder with its own Program.cs file.